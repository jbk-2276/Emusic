from django.apps import AppConfig


class EmusicAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Emusic_app'
